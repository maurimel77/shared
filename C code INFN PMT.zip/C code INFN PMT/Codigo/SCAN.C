#include<process.h>
#include<graphics.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
FILE *fecha, *ns, *bin;

void main(void)
{

int i=0, cantidad=0;
double f[5655];       
int n[5655], p[5655]; 

clrscr();

//------------------ Inicio de modo de video (por culpa del XP?) ---------
// Ponerlo una sola vez, despues se anula y se ve en pantalla completa.

  // int gdriver = DETECT, gmode;
    //  initgraph(&gdriver, &gmode, "c:\\tc\\bgi");


//---------------- Lectura de los archivos -------------------------------

   if ((fecha = fopen("d:\\docs\\progs\\tc\\fecha.txt", "r"))
       == NULL)
   {
   printf(" \nError abriendo archivo.\n");
   exit(1);
   }

   rewind(fecha);
   while(cantidad<5655)    // !feof(fecha)
      {
	fscanf(fecha,"%lf",&f[i]);  /* Lee la variable "f"(fecha) desde el archivo 
*/
	i++;
	cantidad++;
      }


   i=0;
   cantidad=0;

   if ((ns = fopen("d:\\docs\\progs\\tc\\ns.txt", "r"))
       == NULL)
   {
   printf(" \nError abriendo archivo.\n");
   exit(1);
   }

   while(cantidad<5655)
      {
	fscanf(ns,"%d",&n[i]);  /* Lee la variable "n"(numero de serie)
					desde el archivo */
	i++;
	cantidad++;
      }

printf("cant = %d \n",cantidad);

     printf("Num de serie: \n");  getch();
     for(i=0; i<cantidad; i++) {  printf( "num de serie: %d \n",n[i]); }

fclose(fecha);
fclose(ns);

//---------------- Clasificacion de las lecturas ---------------------------

/* Para las unidades que han sido testeadas mas de una vez con periodo de
   tiempo mayor a 2 horas, en el archivo pp.txt (Pre - Post burn in)
   le corresponde un 1, en caso contrario un 0.
   Aquellas unidades que han sido testeadas una sola vez, las identifico con
   un numero 2. */

i=0;
printf("cant = %d \n",cantidad);

if ( n[1] != n[0] )
	{
	 p[0] = 2;
	 i=1;
	}

else if ( n[1] == n[0] )
		{
		if ( ( f[1] - f[0] ) > 2 )
				    { p[0] = 0;     p[1] = 1; }

		if ( ( f[0] - f[1] ) > 2 )
				    { p[0] = 1;     p[1] = 0; }

		if ( abs( f[1] - f[0] ) < 2 )
				    { p[0] = 0;     p[1] = 0; }
		i=2;
		}

do
      {
	if ( ( n[i] != n[i-1] ) && ( n[i] != n[i+1] ) )
	       {
	       p[i] = 2;
	       i++;
	       }

	else if ( n[i] == n[i-1] )
		{
	    if ( ( f[i] - f[i-1] ) > 2 )  { p[i] = 1;  p[i-1] = 0; }

	    else if ( ( f[i-1] - f[i] ) > 2 )  { p[i] = 0;  p[i-1] = 1; }

	    else if ( abs( f[i] - f[i-1] ) < 2 )  { p[i] = 0; p[i-1] = 0; }
		i++;
		}

	else if ( n[i] == n[i+1] )
		{
	    if ( ( f[i] - f[i+1] ) > 2 )  { p[i] = 1;  p[i+1] = 0; }

	    else if ( ( f[i+1] - f[i] ) > 2 )  { p[i] = 0;  p[i+1] = 1;	}

	    else if ( abs( f[i] - f[i+1] ) < 2 )  { p[i] = 0; p[i+1] = 0; }

 
		i+=2;
		}



	}

  while (i<cantidad);


printf("\n");
i=0;
     while(i<cantidad)
     {
       printf( "p[%d]= %d\tp[%d]= %d\tp[%d]= %d\tp[%d]= %d\t \n",i,p[i],
       i+1, p[i+1], i+2, p[i+2], i+3, p[i+3]);
       i+=4;
     }


getch();
}




