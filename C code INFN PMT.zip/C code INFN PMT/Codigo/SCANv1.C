#include<stdlib.h>
#include<stdio.h>
FILE *fecha, *ns, *bin;

void main(void)
{

int i=0, cantidad=0;
double f[6151];       // cambiar por 5655
short int n[6151], p[6151];          // cambiar por 5655

//---------------- Lectura de los archivos -------------------------------

   if ((fecha = fopen("/home/melocchi/Mis_programas/b1_total_unidades.txt", "r"))
       == NULL)
   {
   printf(" \nError abriendo archivo.\n");
   exit(1);
   }

   rewind(fecha);
   while(!feof(fecha))
      {
	fscanf(fecha,"%lf",&f[i]);  /* Lee la variable "f"(fecha) desde el archivo */
	i++;
	cantidad++;
      }

       printf("Fechas: \n");

   i=0;
   cantidad=0;

   if ((ns = fopen("/home/melocchi/Mis_programas/nsb1.txt", "r"))
       == NULL)
   {
   printf(" \nError abriendo archivo.\n");
   exit(1);
   }

   while(!feof(ns))
      {
	fscanf(ns,"%d",&n[i]);  /* Lee la variable "n"(numero de serie)
					desde el archivo */
	i++;
	cantidad++;
      }

printf("cant = %d \n",cantidad);

     printf("Num de serie: \n");
     for(i=0; i<cantidad; i++) {  printf( "num de serie: %d \n",n[i]); }

fclose(fecha);
fclose(ns);

//---------------- Clasificacion de las lecturas ---------------------------

/* Para las unidades que han sido testeadas mas de una vez con periodo de
   tiempo mayor a 2 horas, en el archivo pp.txt (Pre - Post burn in)
   le corresponde un 1, en caso contrario un 0.
   Aquellas unidades que han sido testeadas una sola vez, las identifico con
   un numero 2. */

i=0;
printf("cant = %d \n",cantidad);

if ( n[1] != n[0] )
	{
	 p[0] = 2;
	 i=1;
	}

else if ( n[1] == n[0] )
		{
		if ( ( f[1] - f[0] ) > 2 )
				    { p[0] = 0;     p[1] = 1; }

		if ( ( f[0] - f[1] ) > 2 )
				    { p[0] = 1;     p[1] = 0; }

		if ( abs( f[1] - f[0] ) < 2 )
				    { p[0] = 0;     p[1] = 0; }
		i=2;
		}

    do
      {
	if ( ( n[i] != n[i-1] ) && ( n[i] != n[i+1] ) )
	       {
	       p[i] = 2;
	       i++;
	       }

	else if ( n[i] == n[i-1] )
		{
	    if ( ( f[i] - f[i-1] ) > 2 )  { p[i] = 1;  p[i-1] = 0; }

	    else if ( ( f[i-1] - f[i] ) > 2 )  { p[i] = 0;  p[i-1] = 1; }

	    else if ( abs( f[i] - f[i-1] ) < 2 )  { p[i] = 0; p[i-1] = 0; }
		i++;
		}

	else if ( n[i] == n[i+1] )
		{
	    if ( ( f[i] - f[i+1] ) > 2 )  { p[i] = 1;  p[i+1] = 0; }

	    else if ( ( f[i+1] - f[i] ) > 2 )  { p[i] = 0;  p[i+1] = 1;	}

	    else if ( abs( f[i] - f[i+1] ) < 2 )  { p[i] = 0; p[i+1] = 0; }
		i+=2;
		}
	}
         while (i<cantidad);


printf("\n");
i=0;

if ((bin = fopen("/home/melocchi/Mis_programas/pre-post.txt", "w"))
       == NULL)
   {
   printf(" \nError abriendo archivo.\n");
   exit(1);
   }


     while(i<cantidad)
     {
       fprintf(bin, "%d\n",p[i]);
       i++;
     }

i=0;

     while(i<cantidad)  //muestra el contenido de los datos archivados en pre-post.txt
     {
       printf( "p[%d]= %d\tp[%d]= %d\tp[%d]= %d\tp[%d]= %d\t \n",i,p[i],
       i+1, p[i+1], i+2, p[i+2], i+3, p[i+3]);
       i+=4;

     }
}

